<?php
/**
 *
 * @author Greg Kappatos
 *
 * File for the tests to simulate a web page.
 *
 */
echo 'Hello World!';