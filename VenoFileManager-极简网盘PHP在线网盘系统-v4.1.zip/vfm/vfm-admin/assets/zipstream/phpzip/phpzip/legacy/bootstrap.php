<?php
/**
 *
 * @author Greg Kappatos
 *
 * Not used atm.
 *
 */
$loader = require 'vendor/autoload.php';
